dpkg --build nessy/ nessy-11.11.1_all.deb

echo ''
echo 'Build apt package: https://gna.org/cookbook/?func=detailitem&item_id=118'
echo 'Upload: https://gna.org/cookbook/?func=detailitem&item_id=119'
echo ''
echo ''

